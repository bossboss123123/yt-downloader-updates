#!/bin/bash
cd "$(dirname "$0")"
rm -f "YTDownloaderServer.app/Contents/Resources/app/license.key" "extension/license.key"
echo "已清除本機授權。"
read -n 1 -s -r -p "按任意鍵關閉"
