YT Downloader Commercial v3.3 FINAL PACKAGE

功能：
- 授權啟用 / 解除授權 / 重新綁定
- 啟用後隱藏序號輸入框
- 未授權：popup 與 server 端都禁止下載
- 背景自動啟動 server，不需要手動開 server.py
- 解析畫質、MP4、MP3、M4A、進度、速度、ETA
- 手動更新架構

安裝：
1. 解壓縮此資料夾。
2. 右鍵打開 install.command。
3. 到 chrome://extensions/，開發人員模式，載入 extension 資料夾。
4. 開 YouTube 影片頁。
5. 輸入 DEMO-1234 啟用。

解除安裝：
- 執行 uninstall.command

重設授權：
- 執行 reset_license.command

注意：
此包是 macOS 背景服務版。server 會由 LaunchAgent 自動啟動。
若電腦沒有 yt-dlp 或 ffmpeg，install.command 會嘗試用 Homebrew 安裝。
正式販售若要完全不依賴使用者電腦，需另外用 PyInstaller/Briefcase 打包 Python runtime、yt-dlp、ffmpeg 成真正的 binary/app/pkg。
