#!/bin/bash
cd "$(dirname "$0")"
chmod +x install.command uninstall.command reset_license.command 2>/dev/null || true
chmod +x YTDownloaderServer.app/Contents/MacOS/YTDownloaderServer 2>/dev/null || true
open -a Terminal install.command
