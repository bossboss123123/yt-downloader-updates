#!/bin/bash
PLIST="$HOME/Library/LaunchAgents/com.ytdownloader.server.plist"
launchctl bootout gui/$(id -u) "$PLIST" 2>/dev/null || true
rm -f "$PLIST"
OLD_PIDS=$(lsof -ti tcp:8765 2>/dev/null || true)
if [ -n "$OLD_PIDS" ]; then kill $OLD_PIDS 2>/dev/null || true; fi
echo "已移除背景 server。"
read -n 1 -s -r -p "按任意鍵關閉"
