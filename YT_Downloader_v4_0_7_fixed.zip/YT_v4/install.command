#!/bin/bash
set -e
cd "$(dirname "$0")"
APP="$PWD/YTDownloaderServer.app"
PLIST="$HOME/Library/LaunchAgents/com.ytdownloader.server.plist"
LOG_DIR="$HOME/Library/Logs/YTDownloader"

STEP=0
TOTAL=9

progress(){
  STEP=$((STEP+1))
  FILLED=""
  EMPTY=""
  for i in $(seq 1 $STEP); do FILLED="${FILLED}█"; done
  for i in $(seq $STEP $TOTAL); do EMPTY="${EMPTY}░"; done
  PCT=$(( STEP * 100 / TOTAL ))
  printf "\r[%s%s] %d%%  %s        " "$FILLED" "$EMPTY" "$PCT" "$1"
}

echo ""
echo "╔══════════════════════════════════╗"
echo "║      YT Downloader 安裝程式      ║"
echo "╚══════════════════════════════════╝"
echo ""
echo "【法律聲明與免責聲明】"
echo "本軟體僅供個人合法使用。使用者須自行確認"
echo "於所在地區下載影片是否符合當地法律規範。"
echo ""
echo "本軟體不得用於："
echo "  · 下載受版權保護之內容進行商業用途"
echo "  · 大量下載或散布他人著作"
echo "  · 任何違反 YouTube 服務條款之商業行為"
echo ""
echo "開發者不對使用者之任何行為負法律責任。"
echo "繼續安裝即表示您已閱讀並同意上述聲明。"
echo "══════════════════════════════════════"
read -n 1 -s -r -p "按任意鍵繼續安裝，或關閉視窗取消..."
echo ""
echo ""

progress "建立目錄..."
mkdir -p "$LOG_DIR" "$HOME/Library/LaunchAgents"

progress "設定權限..."
chmod +x "$APP/Contents/MacOS/YTDownloaderServer" 2>/dev/null || true
xattr -dr com.apple.quarantine "$APP" 2>/dev/null || true

progress "停止舊版 server..."
OLD_PIDS=$(lsof -ti tcp:8765 2>/dev/null || true)
if [ -n "$OLD_PIDS" ]; then
  kill $OLD_PIDS 2>/dev/null || true
  sleep 1
fi

progress "安裝 Homebrew..."
if ! command -v brew >/dev/null 2>&1; then
  echo ""
  echo "正在安裝 Homebrew（需要網路，約 2-5 分鐘）..."
  /bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"
  # Apple Silicon
  if [ -f /opt/homebrew/bin/brew ]; then
    eval "$(/opt/homebrew/bin/brew shellenv)"
    echo 'eval "$(/opt/homebrew/bin/brew shellenv)"' >> "$HOME/.zprofile"
  fi
fi
eval "$(brew shellenv 2>/dev/null)" || true

progress "安裝 yt-dlp..."
if ! command -v yt-dlp >/dev/null 2>&1; then
  brew install yt-dlp -q
else
  brew upgrade yt-dlp -q 2>/dev/null || true
fi

progress "安裝 ffmpeg..."
if ! command -v ffmpeg >/dev/null 2>&1; then
  brew install ffmpeg -q
fi

progress "安裝 python3..."
if ! command -v python3 >/dev/null 2>&1; then
  brew install python3 -q
fi

progress "啟動背景服務..."
cat > "$PLIST" <<PLIST
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
  <key>Label</key><string>com.ytdownloader.server</string>
  <key>ProgramArguments</key>
  <array><string>$APP/Contents/MacOS/YTDownloaderServer</string></array>
  <key>RunAtLoad</key><true/>
  <key>KeepAlive</key><true/>
  <key>StandardOutPath</key><string>$LOG_DIR/server.log</string>
  <key>StandardErrorPath</key><string>$LOG_DIR/server.err.log</string>
  <key>WorkingDirectory</key><string>$APP/Contents/Resources/app</string>
</dict>
</plist>
PLIST
launchctl bootout gui/$(id -u) "$PLIST" 2>/dev/null || true
launchctl bootstrap gui/$(id -u) "$PLIST"
launchctl kickstart -k gui/$(id -u)/com.ytdownloader.server
sleep 2

progress "啟用授權..."
echo ""
echo ""
echo "────────────────────────────────────"

while true; do
  read -p "請輸入序號：" LICENSE_KEY
  LICENSE_KEY=$(echo "$LICENSE_KEY" | tr -d '[:space:]')
  if [ -z "$LICENSE_KEY" ]; then
    echo "序號不能空白，請重新輸入。"
    continue
  fi
  RESULT=$(curl -s -X POST http://127.0.0.1:8765/license/activate \
    -H "Content-Type: application/json" \
    -d "{\"license\":\"$LICENSE_KEY\"}" 2>/dev/null || echo "")
  if echo "$RESULT" | python3 -c "import sys,json; d=json.load(sys.stdin); exit(0 if d.get('result',{}).get('valid') else 1)" 2>/dev/null; then
    echo "✓ 序號啟用成功！"
    break
  else
    MSG=$(echo "$RESULT" | python3 -c "import sys,json; d=json.load(sys.stdin); print(d.get('result',{}).get('message','啟用失敗'))" 2>/dev/null || echo "啟用失敗，請確認 server 已啟動")
    echo "✗ $MSG"
    read -p "重試？(y/n)：" RETRY
    if [ "$RETRY" != "y" ] && [ "$RETRY" != "Y" ]; then break; fi
  fi
done

echo ""
echo "════════════════════════════════════"
echo "  ✓ 安裝完成！"
echo "════════════════════════════════════"
echo "  請到 chrome://extensions/ 載入"
echo "  extension 資料夾。"
echo "  之後所有操作都在外掛的 ⚙️ 設定內。"
echo "════════════════════════════════════"
echo ""
read -n 1 -s -r -p "按任意鍵關閉"
